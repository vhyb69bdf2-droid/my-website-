/* ═══════════════════════════════════════════════════════════
   CipherRoom — app.js
   ═══════════════════════════════════════════════════════════ */

"use strict";

/* ─── Firebase ──────────────────────────────────────────── */
const FB_CFG = window.CIPHERROOM_FIREBASE || {};
let db = null;
let firebaseLoadStarted = false;
(function initFirebase() {
  if (!FB_CFG.databaseURL) return;
  firebaseLoadStarted = true;
  const script = document.createElement("script");
  script.src = "https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js";
  script.onload = () => {
    const s2 = document.createElement("script");
    s2.src = "https://www.gstatic.com/firebasejs/9.22.2/firebase-database-compat.js";
    s2.onload = () => {
      firebase.initializeApp({ databaseURL: FB_CFG.databaseURL });
      db = firebase.database();
    };
    document.head.appendChild(s2);
  };
  document.head.appendChild(script);
})();

function fbRef(path) { return db ? db.ref(path) : null; }

function withDatabase(label, cb) {
  if (db) { cb(); return; }
  if (!FB_CFG.databaseURL || !firebaseLoadStarted) {
    alert(`${label} needs Firebase Realtime Database to be configured.`);
    return;
  }
  let tries = 0;
  const wait = setInterval(() => {
    tries++;
    if (db) {
      clearInterval(wait);
      cb();
    } else if (tries >= 50) {
      clearInterval(wait);
      alert(`${label} is still connecting to Firebase. Try again in a moment.`);
    }
  }, 100);
}

/* ─── Utilities ─────────────────────────────────────────── */
function randomCode(len) {
  const d = [0,1,2,3,4,5,6,7,8,9];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d.slice(0, len).join("");
}

function randomRoomCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function isValidCode(str, len) {
  if (!str || str.length !== len) return false;
  if (!/^\d+$/.test(str)) return false;
  return new Set(str).size === len;
}

function scoreGuess(secret, guess) {
  let greens = 0, yellows = 0;
  for (let i = 0; i < secret.length; i++) {
    if (guess[i] === secret[i]) greens++;
    else if (secret.includes(guess[i])) yellows++;
  }
  return { greens, yellows };
}

function buildHistoryItem(guess, greens, yellows, label) {
  const li = document.createElement("li");
  li.className = "history-item";
  const cluesHtml = guess.split("").map((d, i) => {
    let cls = "gray";
    // we need to recompute per digit for display
    return `<div class="clue ${cls}">${d}</div>`;
  }).join("");
  // recompute proper colors
  li.innerHTML = `<div class="guess-number">${label || guess}</div><div class="clues" id="_pending"></div>`;
  return li;
}

function renderHistoryItem(secret, guess, guessLabel) {
  const li = document.createElement("li");
  li.className = "history-item";
  const clues = [];
  const secretArr = secret.split("");
  const guessArr = guess.split("");
  const used = new Array(secret.length).fill(false);
  const result = new Array(guess.length).fill("gray");
  // greens first
  for (let i = 0; i < guessArr.length; i++) {
    if (guessArr[i] === secretArr[i]) { result[i] = "green"; used[i] = true; }
  }
  // yellows
  for (let i = 0; i < guessArr.length; i++) {
    if (result[i] === "green") continue;
    for (let j = 0; j < secretArr.length; j++) {
      if (!used[j] && guessArr[i] === secretArr[j]) { result[i] = "yellow"; used[j] = true; break; }
    }
  }
  const html = guessArr.map((d, i) => `<div class="clue ${result[i]}">${d}</div>`).join("");
  li.innerHTML = `<div class="guess-number">${guessLabel}</div><div class="clues">${html}</div>`;
  return li;
}

// Version that renders without knowing secret (for opponent's guesses shown with counts only)
function renderHistoryItemPublic(guess, greens, yellows, guessLabel) {
  const li = document.createElement("li");
  li.className = "history-item";
  const cluesHtml = guess.split("").map(d => `<div class="clue gray">${d}</div>`).join("");
  li.innerHTML = `<div class="guess-number">${guessLabel}</div>
    <div style="display:grid;gap:6px">
      <div class="clues">${cluesHtml}</div>
      <div style="font-size:.78rem;color:var(--muted)">${greens} green / ${yellows} yellow</div>
    </div>`;
  return li;
}

function showMessage(elId, msg, color) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = msg;
  el.style.display = "block";
  el.style.borderColor = color || "var(--line)";
}

function hideMessage(elId) {
  const el = document.getElementById(elId);
  if (el) el.style.display = "none";
}

/* ─── Page routing ──────────────────────────────────────── */
const PAGES = ["pageHome","pageModePicker","pageNovaSetup","pageMultiSetup","pageGroupSetup","pageLobby","pageNovaGame","pageMultiGame","pageGroupGame"];

window.showPage = function(id) {
  PAGES.forEach(p => { const el = document.getElementById(p); if (el) el.style.display = "none"; });
  const target = document.getElementById(id);
  if (target) target.style.display = target.classList.contains("setup-page") ? "grid" : "block";
  window.scrollTo(0, 0);
};

window.showModePicker = function() { showPage("pageModePicker"); };

window.startMode = function(mode) {
  if (mode === "nova") showPage("pageNovaSetup");
  else if (mode === "multiplayer") showPage("pageMultiSetup");
  else if (mode === "group") showPage("pageGroupSetup");
};

/* ─── Theme toggle ──────────────────────────────────────── */
(function() {
  const saved = localStorage.getItem("crTheme");
  if (saved === "light") document.documentElement.classList.add("light");
  document.getElementById("themeToggle").addEventListener("click", () => {
    const isLight = document.documentElement.classList.toggle("light");
    localStorage.setItem("crTheme", isLight ? "light" : "dark");
  });
})();

/* ─── Nav / home buttons ────────────────────────────────── */
document.getElementById("brandHome").addEventListener("click", () => showPage("pageHome"));
document.getElementById("navPlay").addEventListener("click", (e) => { e.preventDefault(); showModePicker(); });
document.getElementById("heroPlay").addEventListener("click", () => showModePicker());
document.getElementById("heroHowto").addEventListener("click", () => {
  document.getElementById("howtoOverlay").style.display = "flex";
});
document.querySelectorAll("button:not([type])").forEach(btn => { btn.type = "button"; });

/* ─── Segmented controls helper ────────────────────────── */
function initSegmented(containerId, cb) {
  const seg = document.getElementById(containerId);
  if (!seg) return;
  seg.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => {
      seg.querySelectorAll("button").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      if (cb) cb(btn.dataset.val);
    });
  });
}
function segValue(containerId) {
  const seg = document.getElementById(containerId);
  if (!seg) return null;
  const active = seg.querySelector("button.active");
  return active ? active.dataset.val : null;
}

initSegmented("novaDiffSeg");
initSegmented("multiJoinSeg", v => {
  document.getElementById("multiJoinCodeWrap").style.display = v === "join" ? "block" : "none";
});
initSegmented("multiModeSeg");
initSegmented("groupJoinSeg", v => {
  document.getElementById("groupJoinCodeWrap").style.display = v === "join" ? "block" : "none";
  ["groupSizeWrap","groupDigitsWrap","groupModeWrap","groupVisWrap"].forEach(id => {
    document.getElementById(id).style.display = v === "create" ? "block" : "none";
  });
});
initSegmented("groupModeSeg");
initSegmented("groupVisSeg");

/* ══════════════════════════════════════════════════════════
   ROUND END OVERLAY
══════════════════════════════════════════════════════════ */
function showRoundEnd(title, msg, buttons) {
  document.getElementById("roundEndTitle").textContent = title;
  document.getElementById("roundEndMsg").textContent = msg;
  const wrap = document.getElementById("roundEndButtons");
  wrap.innerHTML = "";
  buttons.forEach(b => {
    const btn = document.createElement("button");
    btn.className = b.primary ? "primary-action" : "secondary-action";
    btn.textContent = b.label;
    btn.addEventListener("click", () => {
      document.getElementById("roundEndOverlay").style.display = "none";
      b.action();
    });
    wrap.appendChild(btn);
  });
  document.getElementById("roundEndOverlay").style.display = "flex";
}

/* ══════════════════════════════════════════════════════════
   DIGIT TRACKER
══════════════════════════════════════════════════════════ */
function buildDigitTracker(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = "";
  for (let i = 0; i <= 9; i++) {
    const cell = document.createElement("div");
    cell.className = "digit-cell";
    cell.id = `${containerId}_d${i}`;
    cell.innerHTML = `<span>${i}</span><span id="${containerId}_s${i}" style="color:var(--muted)">?</span>`;
    el.appendChild(cell);
  }
}

function updateTracker(containerId, digit, status) {
  // status: 'green','yellow','gray'
  const el = document.getElementById(`${containerId}_s${digit}`);
  if (!el) return;
  const colors = { green: "var(--green)", yellow: "var(--yellow)", gray: "var(--muted)" };
  const symbols = { green: "✓", yellow: "~", gray: "✗" };
  el.textContent = symbols[status] || "?";
  el.style.color = colors[status] || "var(--muted)";
}

function applyGuessToTracker(containerId, secret, guess) {
  const secretArr = secret.split("");
  const guessArr = guess.split("");
  const used = new Array(secret.length).fill(false);
  const result = {};
  guessArr.forEach((d, i) => {
    if (d === secretArr[i]) { result[d] = "green"; used[i] = true; }
  });
  guessArr.forEach((d, i) => {
    if (result[d] === "green") return;
    let found = false;
    for (let j = 0; j < secretArr.length; j++) {
      if (!used[j] && d === secretArr[j]) { found = true; used[j] = true; break; }
    }
    result[d] = found ? "yellow" : "gray";
  });
  Object.entries(result).forEach(([d, s]) => updateTracker(containerId, d, s));
}

/* ══════════════════════════════════════════════════════════
   NOVA AI
══════════════════════════════════════════════════════════ */
const Nova = (() => {
  let candidates = [];
  let difficulty = "medium";

  function allCodes(len) {
    const res = [];
    function gen(cur) {
      if (cur.length === len) { res.push(cur); return; }
      for (let d = 0; d <= 9; d++) {
        if (!cur.includes(String(d))) gen(cur + d);
      }
    }
    gen("");
    return res;
  }

  function filterCandidates(guess, greens, yellows) {
    candidates = candidates.filter(c => {
      const s = scoreGuess(c, guess);
      return s.greens === greens && s.yellows === yellows;
    });
  }

  function pickGuess() {
    if (difficulty === "easy") {
      // random from candidates but filter some noise
      return candidates[Math.floor(Math.random() * Math.min(candidates.length, 8))];
    }
    if (difficulty === "medium") {
      // pick a random from top half of candidates
      const top = candidates.slice(0, Math.ceil(candidates.length / 2));
      return top[Math.floor(Math.random() * top.length)];
    }
    // impossible: minimax-lite — pick guess that maximally reduces candidates
    if (candidates.length <= 2) return candidates[0];
    let bestGuess = candidates[0];
    let bestWorst = Infinity;
    // sample to keep performance reasonable
    const sample = candidates.length > 200 ? candidates.filter((_, i) => i % 5 === 0) : candidates;
    sample.forEach(g => {
      const buckets = {};
      candidates.forEach(c => {
        const s = scoreGuess(c, g);
        const k = `${s.greens},${s.yellows}`;
        buckets[k] = (buckets[k] || 0) + 1;
      });
      const worst = Math.max(...Object.values(buckets));
      if (worst < bestWorst) { bestWorst = worst; bestGuess = g; }
    });
    return bestGuess;
  }

  return {
    init(len, diff) {
      difficulty = diff;
      candidates = allCodes(len);
    },
    makeGuess() { return pickGuess(); },
    update(guess, greens, yellows) { filterCandidates(guess, greens, yellows); },
    remaining() { return candidates.length; }
  };
})();

/* ══════════════════════════════════════════════════════════
   NOVA GAME STATE
══════════════════════════════════════════════════════════ */
const NovaGame = (() => {
  let state = {};

  function reset() {
    state = {
      playerName: "Player",
      digits: 4,
      difficulty: "medium",
      playerSecret: null,
      novaSecret: null,
      locked: false,
      round: 1,
      playerScore: 0,
      novaScore: 0,
      playerGuesses: [],
      novaGuesses: [],
      gameOver: false
    };
  }

  function start(name, digits, diff) {
    reset();
    state.playerName = name || "Player";
    state.digits = parseInt(digits);
    state.difficulty = diff;
    state.novaSecret = randomCode(state.digits);
    Nova.init(state.digits, diff);

    document.getElementById("novaGameTitle").textContent = `${state.playerName} vs Nova`;
    document.getElementById("novaDiffBadge").textContent = diff.charAt(0).toUpperCase() + diff.slice(1);
    document.getElementById("novaSecretInput").maxLength = state.digits;
    document.getElementById("novaSecretInput").disabled = false;
    document.getElementById("novaLockBtn").disabled = false;
    document.getElementById("novaGuessInput").maxLength = state.digits;
    document.getElementById("novaGuessInput").placeholder = `e.g. ${randomCode(state.digits)}`;
    document.getElementById("novaSecretInput").placeholder = `e.g. ${randomCode(state.digits)}`;
    document.getElementById("novaSecretPanel").style.display = "grid";
    document.getElementById("novaSecretLocked").style.display = "none";
    document.getElementById("novaGuessInput").disabled = true;
    document.getElementById("novaGuessBtn").disabled = true;
    buildDigitTracker("novaDigitGrid");
    renderNovaUI();
    showPage("pageNovaGame");
  }

  function lockSecret() {
    if (state.locked) return;
    const val = document.getElementById("novaSecretInput").value.trim();
    if (!isValidCode(val, state.digits)) {
      showMessage("novaMessage", `Secret must be ${state.digits} unique digits.`, "var(--red)");
      return;
    }
    state.playerSecret = val;
    state.locked = true;
    document.getElementById("novaSecretInput").disabled = true;
    document.getElementById("novaLockBtn").disabled = true;
    document.getElementById("novaSecretPanel").style.display = "none";
    document.getElementById("novaSecretLocked").style.display = "block";
    document.getElementById("novaGuessInput").disabled = false;
    document.getElementById("novaGuessBtn").disabled = false;
    hideMessage("novaMessage");
  }

  function submitGuess(raw) {
    if (!state.locked || state.gameOver) return;
    const guess = raw.trim();
    if (!isValidCode(guess, state.digits)) {
      showMessage("novaMessage", `Guess must be ${state.digits} unique digits.`, "var(--red)");
      return;
    }
    hideMessage("novaMessage");

    // Player guesses Nova's secret
    const { greens, yellows } = scoreGuess(state.novaSecret, guess);
    state.playerGuesses.push({ guess, greens, yellows });
    applyGuessToTracker("novaDigitGrid", state.novaSecret, guess);
    renderNovaUI();
    document.getElementById("novaGuessInput").value = "";

    if (greens === state.digits) {
      state.playerScore++;
      endRound(`${state.playerName} cracked it!`, `The code was ${state.novaSecret}. You got it in ${state.playerGuesses.length} guesses.`, true);
      return;
    }

    // Nova guesses player's secret
    setTimeout(() => {
      const novaGuess = Nova.makeGuess();
      const ns = scoreGuess(state.playerSecret, novaGuess);
      Nova.update(novaGuess, ns.greens, ns.yellows);
      state.novaGuesses.push({ guess: novaGuess, greens: ns.greens, yellows: ns.yellows });
      renderNovaUI();
      if (ns.greens === state.digits) {
        state.novaScore++;
        endRound("Nova cracked your code!", `Nova guessed ${state.playerSecret} in ${state.novaGuesses.length} tries.`, false);
      }
    }, 700);
  }

  function endRound(title, msg, playerWon) {
    state.gameOver = true;
    document.getElementById("novaGuessBtn").disabled = true;
    document.getElementById("novaGuessInput").disabled = true;
    showRoundEnd(title, msg, [
      { label: "Next Round", primary: true, action: () => nextRound() },
      { label: "Quit", primary: false, action: () => { novaQuit(); } }
    ]);
  }

  function nextRound() {
    state.round++;
    state.playerGuesses = [];
    state.novaGuesses = [];
    state.locked = false;
    state.gameOver = false;
    state.novaSecret = randomCode(state.digits);
    Nova.init(state.digits, state.difficulty);
    document.getElementById("novaSecretInput").value = "";
    document.getElementById("novaSecretInput").disabled = false;
    document.getElementById("novaLockBtn").disabled = false;
    document.getElementById("novaSecretPanel").style.display = "grid";
    document.getElementById("novaSecretLocked").style.display = "none";
    document.getElementById("novaGuessInput").disabled = true;
    document.getElementById("novaGuessBtn").disabled = true;
    buildDigitTracker("novaDigitGrid");
    renderNovaUI();
  }

  function renderNovaUI() {
    document.getElementById("novaRoundBadge").textContent = `Round ${state.round}`;
    document.getElementById("novaScoreBadge").textContent = `${state.playerScore} – ${state.novaScore}`;
    document.getElementById("novaYourGuessCount").textContent = state.playerGuesses.length;
    document.getElementById("novaNovaGuessCount").textContent = state.novaGuesses.length;

    const yourList = document.getElementById("novaYourHistory");
    yourList.innerHTML = "";
    state.playerGuesses.forEach((g, i) => {
      yourList.appendChild(renderHistoryItem(state.novaSecret, g.guess, `#${i+1} — ${g.guess}`));
    });

    const novaList = document.getElementById("novaNovaHistory");
    novaList.innerHTML = "";
    state.novaGuesses.forEach((g, i) => {
      novaList.appendChild(renderHistoryItemPublic(g.guess, g.greens, g.yellows, `#${i+1} — ${g.guess}`));
    });
  }

  return { start, lockSecret, submitGuess };
})();

window.novaQuit = function() { showPage("pageHome"); };
document.getElementById("novaLockBtn").addEventListener("click", e => {
  e.preventDefault();
  NovaGame.lockSecret();
});
document.getElementById("novaGuessBtn").addEventListener("click", e => {
  e.preventDefault();
  NovaGame.submitGuess(document.getElementById("novaGuessInput").value);
});
document.getElementById("novaGuessInput").addEventListener("keydown", e => {
  if (e.key === "Enter") {
    e.preventDefault();
    NovaGame.submitGuess(document.getElementById("novaGuessInput").value);
  }
});

document.getElementById("novaStartBtn").addEventListener("click", e => {
  e.preventDefault();
  const name = document.getElementById("novaPlayerName").value.trim() || "Player";
  const digits = document.getElementById("novaDigits").value;
  const diff = segValue("novaDiffSeg") || "medium";
  NovaGame.start(name, digits, diff);
});

/* ══════════════════════════════════════════════════════════
   MULTIPLAYER GAME STATE
══════════════════════════════════════════════════════════ */
const MultiGame = (() => {
  let state = {};
  let listeners = [];
  let timerInterval = null;

  function clearListeners() {
    listeners.forEach(off => off());
    listeners = [];
  }

  function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  }

  function reset() {
    clearListeners();
    stopTimer();
    state = {
      roomCode: null,
      playerId: null, // "p1" or "p2"
      playerName: "",
      opponentName: "",
      digits: 4,
      mode: "turns", // "turns" | "realtime"
      round: 1,
      p1Score: 0,
      p2Score: 0,
      mySecret: null,
      myLocked: false,
      oppLocked: false,
      myGuesses: [],
      oppGuesses: [],
      currentTurn: "p1",
      timerSecs: 180,
      gameOver: false,
      gameStarted: false,
      roundStarting: false,
      timerStarted: false
    };
  }

  function createRoom(name, digits, mode) {
    reset();
    if (!db) { alert("Firebase not configured. Multiplayer requires a live database."); return; }
    state.playerName = name || "Player 1";
    state.digits = parseInt(digits);
    state.mode = mode;
    state.playerId = "p1";
    state.roomCode = randomRoomCode();

    showPage("pageLobby");
    document.getElementById("lobbyEyebrow").textContent = "Multiplayer · Waiting for opponent";
    document.getElementById("lobbyTitle").textContent = "Room Code";
    document.getElementById("lobbyRoomCode").textContent = state.roomCode;
    document.getElementById("lobbyStatus").textContent = "Share this code with your friend. Waiting for them to join…";

    const roomRef = fbRef(`rooms/${state.roomCode}`);
    roomRef.set({
      digits: state.digits,
      mode: state.mode,
      round: 1,
      p1: { name: state.playerName, locked: false, secret: "", score: 0 },
      p2: { name: "", locked: false, secret: "", score: 0 },
      currentTurn: "p1",
      phase: "lobby",
      timerEnd: null,
      guesses: { p1: [], p2: [] }
    });

    const handleRoomValue = snap => {
      const data = snap.val();
      if (!data) return;
      if (data.p2 && data.p2.name && data.phase === "lobby") {
        state.opponentName = data.p2.name;
        document.getElementById("lobbyStatus").textContent = `${state.opponentName} joined! Setting up game…`;
        // Move to secret lock phase
        roomRef.update({ phase: "lock" });
      }
      if (data.phase === "lock") {
        clearListeners();
        startGamePhase(data);
      }
    };
    roomRef.on("value", handleRoomValue);
    listeners.push(() => roomRef.off("value", handleRoomValue));
  }

  function joinRoom(name, code) {
    reset();
    if (!db) { alert("Firebase not configured. Multiplayer requires a live database."); return; }
    state.playerName = name || "Player 2";
    state.playerId = "p2";
    state.roomCode = code.toUpperCase();

    const roomRef = fbRef(`rooms/${state.roomCode}`);
    roomRef.once("value", snap => {
      const data = snap.val();
      if (!data) { alert("Room not found. Check the code and try again."); return; }
      state.digits = data.digits;
      state.mode = data.mode;
      state.opponentName = data.p1.name;
      roomRef.child("p2").update({ name: state.playerName, locked: false, secret: "" });

      const handleJoinValue = snap2 => {
        const d2 = snap2.val();
        if (!d2) return;
        state.digits = d2.digits || state.digits;
        state.mode = d2.mode || state.mode;
        state.opponentName = d2.p1 && d2.p1.name ? d2.p1.name : state.opponentName;
        if (d2.phase === "lock") {
          clearListeners();
          startGamePhase(d2);
        } else if (d2.phase === "lobby" && d2.p2 && d2.p2.name) {
          roomRef.update({ phase: "lock" });
        }
      };
      roomRef.on("value", handleJoinValue);
      listeners.push(() => roomRef.off("value", handleJoinValue));

      showPage("pageLobby");
      document.getElementById("lobbyEyebrow").textContent = "Multiplayer · Joined";
      document.getElementById("lobbyTitle").textContent = "Room Code";
      document.getElementById("lobbyRoomCode").textContent = state.roomCode;
      document.getElementById("lobbyStatus").textContent = `Joined ${state.opponentName}'s room. Setting up…`;
    });
  }

  function startGamePhase(data) {
    state.digits = data.digits;
    state.mode = data.mode;
    state.round = data.round || 1;
    state.p1Score = (data.p1 && data.p1.score) || 0;
    state.p2Score = (data.p2 && data.p2.score) || 0;
    state.opponentName = state.playerId === "p1" ? (data.p2 && data.p2.name) : (data.p1 && data.p1.name);
    state.currentTurn = data.currentTurn || "p1";
    state.myGuesses = [];
    state.oppGuesses = [];
    state.gameOver = false;
    state.myLocked = false;
    state.oppLocked = false;
    state.mySecret = null;
    state.gameStarted = false;
    state.timerStarted = false;

    setupMultiGameUI();
    listenForRoomState();
  }

  function setupMultiGameUI() {
    document.getElementById("multiGameTitle").textContent = `${state.playerName} vs ${state.opponentName || "Opponent"}`;
    document.getElementById("multiModeBadge").textContent = state.mode === "turns" ? "Turn-Based" : "Real-Time";
    document.getElementById("multiRoundBadge").textContent = `Round ${state.round}`;
    document.getElementById("multiScoreBadge").textContent = `${state.p1Score} – ${state.p2Score}`;
    document.getElementById("multiRoomBadge").textContent = `Room: ${state.roomCode}`;
    document.getElementById("multiYourLabel").textContent = `${state.playerName}'s Guesses`;
    document.getElementById("multiOppLabel").textContent = `${state.opponentName || "Opponent"}'s Guesses`;
    document.getElementById("multiTimerBadge").style.display = state.mode === "realtime" ? "inline-flex" : "none";
    document.getElementById("multiSecretPanel").style.display = "grid";
    document.getElementById("multiSecretLocked").style.display = "none";
    document.getElementById("multiWaitingOpponent").style.display = "none";
    document.getElementById("multiGameArea").style.display = "none";
    document.getElementById("multiSecretInput").maxLength = state.digits;
    document.getElementById("multiGuessInput").maxLength = state.digits;
    document.getElementById("multiGuessInput").disabled = true;
    document.getElementById("multiGuessBtn").disabled = true;
    document.getElementById("multiLockBtn").disabled = false;
    document.getElementById("multiSecretInput").value = "";
    document.getElementById("multiSecretInput").disabled = false;
    buildDigitTracker("multiDigitGrid");
    hideMessage("multiMessage");
    showPage("pageMultiGame");
  }

  function listenForRoomState() {
    const roomRef = fbRef(`rooms/${state.roomCode}`);
    const handleRoomState = snap => {
      const data = snap.val();
      if (!data) return;
      const myId = state.playerId;
      const oppId = myId === "p1" ? "p2" : "p1";
      state.oppLocked = !!(data[oppId] && data[oppId].locked);
      state.myLocked = !!(data[myId] && data[myId].locked);
      state.currentTurn = data.currentTurn || state.currentTurn || "p1";
      state.p1Score = (data.p1 && data.p1.score) || 0;
      state.p2Score = (data.p2 && data.p2.score) || 0;
      state.opponentName = data[oppId] && data[oppId].name ? data[oppId].name : state.opponentName;
      if (data.round && data.round !== state.round && data.phase === "lock") {
        state.roundStarting = false;
        clearListeners();
        startGamePhase(data);
        return;
      }
      if (data.phase === "lock" && state.gameOver) {
        state.roundStarting = false;
        clearListeners();
        startGamePhase(data);
        return;
      }
      if (state.myLocked) {
        document.getElementById("multiSecretPanel").style.display = "none";
        document.getElementById("multiSecretLocked").style.display = "block";
        document.getElementById("multiWaitingOpponent").style.display = state.oppLocked ? "none" : "block";
      }
      if (state.myLocked && state.oppLocked && data.phase === "lock") {
        roomRef.child("phase").set("playing");
      }
      if (data.phase === "playing") {
        beginPlaying(data);
      } else if (data.phase && data.phase.startsWith("win:")) {
        handleWin(data.phase.split(":")[1]);
      } else if (data.phase === "draw") {
        handleDraw();
      }
    };
    roomRef.on("value", handleRoomState);
    listeners.push(() => roomRef.off("value", handleRoomState));
  }

  function beginPlaying(data) {
    if (state.gameStarted) return;
    state.gameStarted = true;
    state.gameOver = false;
    state.oppSecret = null;
    document.getElementById("multiWaitingOpponent").style.display = "none";
    document.getElementById("multiSecretLocked").textContent = "Secret locked. Game on!";
    document.getElementById("multiGameArea").style.display = "grid";
    fetchOppSecret();
    startTurnListener();
    if (state.mode === "realtime") startRealtimeTimer(data.timerEnd);
  }

  function lockSecret() {
    if (state.myLocked || state.gameStarted) return;
    const val = document.getElementById("multiSecretInput").value.trim();
    if (!isValidCode(val, state.digits)) {
      showMessage("multiMessage", `Secret must be ${state.digits} unique digits.`, "var(--red)");
      return;
    }
    state.mySecret = val;
    state.myLocked = true;
    hideMessage("multiMessage");

    const roomRef = fbRef(`rooms/${state.roomCode}`);
    roomRef.child(state.playerId).update({ locked: true, secret: val });

    document.getElementById("multiSecretPanel").style.display = "none";
    document.getElementById("multiSecretInput").disabled = true;
    document.getElementById("multiLockBtn").disabled = true;
    document.getElementById("multiSecretLocked").style.display = "block";
    document.getElementById("multiSecretLocked").textContent = "Your secret is locked. Waiting for opponent...";
    document.getElementById("multiWaitingOpponent").style.display = state.oppLocked ? "none" : "block";
  }

  function fetchOppSecret() {
    const oppId = state.playerId === "p1" ? "p2" : "p1";
    fbRef(`rooms/${state.roomCode}/${oppId}/secret`).once("value", snap => {
      state.oppSecret = snap.val();
    });
  }

  function startTurnListener() {
    const roomRef = fbRef(`rooms/${state.roomCode}`);
    // Listen for guesses from opponent
    const oppId = state.playerId === "p1" ? "p2" : "p1";
    const off = roomRef.child(`guesses/${oppId}`).on("value", snap => {
      const data = snap.val();
      if (!data) return;
      const arr = Object.values(data).sort((a, b) => a.ts - b.ts);
      state.oppGuesses = arr;
      renderMultiUI();
    });
    listeners.push(() => roomRef.child(`guesses/${oppId}`).off("value", off));

    // Listen for current turn
    const off2 = roomRef.child("currentTurn").on("value", snap => {
      state.currentTurn = snap.val() || "p1";
      updateTurnUI();
    });
    listeners.push(() => roomRef.child("currentTurn").off("value", off2));

    // Listen for phase (win conditions)
  }

  function isMyTurn() {
    if (state.mode === "realtime") return true;
    return state.currentTurn === state.playerId;
  }

  function updateTurnUI() {
    const myTurn = isMyTurn();
    document.getElementById("multiGuessInput").disabled = !myTurn || state.gameOver;
    document.getElementById("multiGuessBtn").disabled = !myTurn || state.gameOver;
    const label = document.getElementById("multiTurnLabel");
    if (state.mode === "turns") {
      label.textContent = myTurn ? "Your turn — make a guess!" : "Waiting for opponent's guess…";
      label.style.borderColor = myTurn ? "var(--cyan)" : "var(--line)";
    } else {
      label.textContent = "Real-Time — guess whenever you want!";
    }
  }

  function submitGuess(raw) {
    if (!isMyTurn() || state.gameOver) return;
    const guess = raw.trim();
    if (!isValidCode(guess, state.digits)) {
      showMessage("multiMessage", `Guess must be ${state.digits} unique digits.`, "var(--red)");
      return;
    }
    if (!state.oppSecret) { showMessage("multiMessage", "Waiting for game to fully sync…", "var(--yellow)"); return; }
    hideMessage("multiMessage");

    const { greens, yellows } = scoreGuess(state.oppSecret, guess);
    const entry = { guess, greens, yellows, ts: Date.now() };
    state.myGuesses.push(entry);

    const roomRef = fbRef(`rooms/${state.roomCode}`);
    const myId = state.playerId;
    const guessKey = `g${state.myGuesses.length}`;
    roomRef.child(`guesses/${myId}/${guessKey}`).set(entry);

    applyGuessToTracker("multiDigitGrid", state.oppSecret, guess);
    document.getElementById("multiGuessInput").value = "";
    renderMultiUI();

    if (greens === state.digits) {
      // I won this round
      const newScore = state.playerId === "p1" ? state.p1Score + 1 : state.p2Score + 1;
      if (state.playerId === "p1") state.p1Score = newScore;
      else state.p2Score = newScore;
      roomRef.update({ [`${state.playerId}/score`]: newScore, phase: `win:${state.playerId}` });
      return;
    }

    // Advance turn in turn-based
    if (state.mode === "turns") {
      const oppId = state.playerId === "p1" ? "p2" : "p1";
      state.currentTurn = oppId;
      updateTurnUI();
      roomRef.child("currentTurn").set(oppId);
    }
  }

  function handleWin(winnerId) {
    if (state.gameOver) return;
    state.gameOver = true;
    stopTimer();
    const iWon = winnerId === state.playerId;
    const winnerName = winnerId === "p1" ? (state.playerId === "p1" ? state.playerName : state.opponentName) : (state.playerId === "p2" ? state.playerName : state.opponentName);
    showRoundEnd(
      iWon ? "You cracked it!" : `${winnerName} wins this round!`,
      `Score: ${state.p1Score} – ${state.p2Score}`,
      [
        { label: "Next Round", primary: true, action: () => nextRound() },
        { label: "Quit", primary: false, action: () => multiQuit() }
      ]
    );
  }

  function handleDraw() {
    if (state.gameOver) return;
    state.gameOver = true;
    stopTimer();
    showRoundEnd("Time's Up!", "Neither player cracked the code in time.",
      [
        { label: "Overtime (+2 min)", primary: true, action: () => startOvertime() },
        { label: "Draw — Quit", primary: false, action: () => multiQuit() }
      ]
    );
  }

  function startOvertime() {
    state.timerSecs = 120;
    state.gameOver = false;
    fbRef(`rooms/${state.roomCode}`).child("timerEnd").set(Date.now() + 120000);
    startRealtimeTimer();
    updateTurnUI();
    document.getElementById("multiGuessInput").disabled = false;
    document.getElementById("multiGuessBtn").disabled = false;
  }

  function startRealtimeTimer(existingEnd) {
    if (state.timerStarted && !existingEnd) return;
    state.timerStarted = true;
    stopTimer();
    const end = existingEnd || Date.now() + state.timerSecs * 1000;
    if (!existingEnd) fbRef(`rooms/${state.roomCode}`).child("timerEnd").set(end);
    const badge = document.getElementById("multiTimerBadge");
    badge.style.display = "inline-flex";
    timerInterval = setInterval(() => {
      const rem = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      const m = Math.floor(rem / 60);
      const s = rem % 60;
      badge.textContent = `${m}:${String(s).padStart(2, "0")}`;
      if (rem === 0) {
        stopTimer();
        if (!state.gameOver) {
          fbRef(`rooms/${state.roomCode}`).child("phase").set("draw");
        }
      }
    }, 500);
  }

  function nextRound() {
    state.round++;
    state.roundStarting = true;
    clearListeners();
    stopTimer();
    state.gameStarted = false;
    state.timerStarted = false;
    const roomRef = fbRef(`rooms/${state.roomCode}`);
    roomRef.update({
      round: state.round,
      phase: "lock",
      currentTurn: "p1",
      timerEnd: null,
      guesses: { p1: {}, p2: {} },
      "p1/locked": false,
      "p1/secret": "",
      "p2/locked": false,
      "p2/secret": ""
    });
    // slight delay for both clients to see the update
    setTimeout(() => startGamePhase({
      digits: state.digits, mode: state.mode, round: state.round,
      currentTurn: "p1",
      p1: { name: state.playerId === "p1" ? state.playerName : state.opponentName, score: state.p1Score },
      p2: { name: state.playerId === "p2" ? state.playerName : state.opponentName, score: state.p2Score }
    }), 300);
  }

  function renderMultiUI() {
    document.getElementById("multiRoundBadge").textContent = `Round ${state.round}`;
    document.getElementById("multiScoreBadge").textContent = `${state.p1Score} – ${state.p2Score}`;
    document.getElementById("multiYourGuessCount").textContent = state.myGuesses.length;
    document.getElementById("multiOppGuessCount").textContent = state.oppGuesses.length;
    updateTurnUI();

    const myList = document.getElementById("multiYourHistory");
    myList.innerHTML = "";
    state.myGuesses.forEach((g, i) => {
      if (state.oppSecret) {
        myList.appendChild(renderHistoryItem(state.oppSecret, g.guess, `#${i+1} — ${g.guess}`));
      }
    });

    const oppList = document.getElementById("multiOppHistory");
    oppList.innerHTML = "";
    state.oppGuesses.forEach((g, i) => {
      oppList.appendChild(renderHistoryItemPublic(g.guess, g.greens, g.yellows, `#${i+1} — ${g.guess}`));
    });
  }

  return { createRoom, joinRoom, lockSecret, submitGuess };
})();

window.multiQuit = function() {
  showPage("pageHome");
};
window.leaveLobby = function() { showPage("pageHome"); };

document.getElementById("lobbyCopyBtn").addEventListener("click", () => {
  const code = document.getElementById("lobbyRoomCode").textContent;
  navigator.clipboard.writeText(code).then(() => {
    document.getElementById("lobbyCopyBtn").textContent = "Copied!";
    setTimeout(() => document.getElementById("lobbyCopyBtn").textContent = "Copy", 2000);
  });
});

document.getElementById("multiStartBtn").addEventListener("click", e => {
  e.preventDefault();
  const name = document.getElementById("multiPlayerName").value.trim() || "Player";
  const joinType = segValue("multiJoinSeg") || "create";
  const digits = document.getElementById("multiDigits").value;
  const mode = segValue("multiModeSeg") || "turns";
  withDatabase("Multiplayer", () => {
    if (joinType === "create") {
      MultiGame.createRoom(name, digits, mode);
    } else {
      const code = document.getElementById("multiJoinCode").value.trim();
      if (!code) { alert("Enter a room code to join."); return; }
      MultiGame.joinRoom(name, code);
    }
  });
});

document.getElementById("multiLockBtn").addEventListener("click", e => {
  e.preventDefault();
  MultiGame.lockSecret();
});
document.getElementById("multiGuessBtn").addEventListener("click", e => {
  e.preventDefault();
  MultiGame.submitGuess(document.getElementById("multiGuessInput").value);
});
document.getElementById("multiGuessInput").addEventListener("keydown", e => {
  if (e.key === "Enter") {
    e.preventDefault();
    MultiGame.submitGuess(document.getElementById("multiGuessInput").value);
  }
});

/* ══════════════════════════════════════════════════════════
   GROUP GAME STATE
══════════════════════════════════════════════════════════ */
const GroupGame = (() => {
  let state = {};
  let listeners = [];
  let timerInterval = null;

  function clearListeners() { listeners.forEach(off => off()); listeners = []; }
  function stopTimer() { if (timerInterval) { clearInterval(timerInterval); timerInterval = null; } }

  function reset() {
    clearListeners();
    stopTimer();
    state = {
      roomCode: null,
      playerId: null,
      playerName: "",
      players: {},
      digits: 4,
      playerCount: 4,
      mode: "turns",
      visibility: "easy",
      round: 1,
      secret: null,
      scores: {},
      guesses: {},
      currentTurn: null,
      timerSecs: 180,
    gameOver: false,
      isHost: false,
      gameStarted: false,
      timerStarted: false
    };
  }

  function createRoom(name, digits, playerCount, mode, visibility) {
    reset();
    if (!db) { alert("Firebase not configured. Group Race requires a live database."); return; }
    state.playerName = name || "Player";
    state.digits = parseInt(digits);
    state.playerCount = parseInt(playerCount);
    state.mode = mode;
    state.visibility = visibility;
    state.roomCode = randomRoomCode();
    state.playerId = "p1";
    state.isHost = true;
    state.secret = randomCode(state.digits);

    const myEntry = { name: state.playerName, ready: true };
    const roomData = {
      digits: state.digits, playerCount: state.playerCount, mode: state.mode,
      visibility: state.visibility, round: 1, phase: "lobby",
      secret: state.secret, currentTurn: "p1",
      players: { p1: myEntry },
      guesses: {},
      scores: { p1: 0 }
    };
    fbRef(`groups/${state.roomCode}`).set(roomData);
    state.players = { p1: myEntry };
    state.scores = { p1: 0 };

    showLobby();
    listenForPlayers();
  }

  function joinRoom(name, code) {
    reset();
    if (!db) { alert("Firebase not configured. Group Race requires a live database."); return; }
    state.playerName = name || "Player";
    state.roomCode = code.toUpperCase();
    state.isHost = false;

    fbRef(`groups/${state.roomCode}`).once("value", snap => {
      const data = snap.val();
      if (!data) { alert("Room not found. Check the code."); return; }
      state.digits = data.digits;
      state.playerCount = data.playerCount;
      state.mode = data.mode;
      state.visibility = data.visibility;
      state.secret = data.secret;

      // Assign next available player id
      const existing = Object.keys(data.players || {});
      const nums = existing.map(k => parseInt(k.slice(1)));
      const next = (Math.max(0, ...nums) + 1);
      state.playerId = `p${next}`;

      fbRef(`groups/${state.roomCode}/players/${state.playerId}`).set({ name: state.playerName, ready: true });
      fbRef(`groups/${state.roomCode}/scores/${state.playerId}`).set(0);

      showLobby();
      listenForPlayers();
    });
  }

  function showLobby() {
    showPage("pageLobby");
    document.getElementById("lobbyEyebrow").textContent = "Group Race · Waiting for players";
    document.getElementById("lobbyTitle").textContent = "Room Code";
    document.getElementById("lobbyRoomCode").textContent = state.roomCode;
    document.getElementById("lobbyStatus").textContent = "Waiting for all players to join…";
  }

  function listenForPlayers() {
    const roomRef = fbRef(`groups/${state.roomCode}`);
    const handlePlayersValue = snap => {
      const data = snap.val();
      if (!data) return;
      state.players = data.players || {};
      state.scores = data.scores || {};

      const count = Object.keys(state.players).length;
      const list = document.getElementById("lobbyPlayerList");
      list.innerHTML = Object.entries(state.players).map(([id, p]) =>
        `<div class="connection-status" style="margin:0">${p.name}${id === state.playerId ? " (You)" : ""}</div>`
      ).join("");

      document.getElementById("lobbyStatus").textContent = `${count} / ${state.playerCount} players joined. ${count < state.playerCount ? "Waiting…" : "Everyone's here!"}`;

      if (count >= state.playerCount && data.phase === "lobby") {
        if (state.isHost) {
          roomRef.child("phase").set("playing");
        }
      }
      if (data.phase === "playing") {
        clearListeners();
        startGroupGame(data);
      }
    };
    roomRef.on("value", handlePlayersValue);
    listeners.push(() => roomRef.off("value", handlePlayersValue));
  }

  function startGroupGame(data) {
    state.players = data.players || {};
    state.scores = data.scores || {};
    state.guesses = {};
    state.currentTurn = data.currentTurn || "p1";
    state.gameOver = false;
    state.round = data.round || 1;
    state.mode = data.mode || state.mode;
    state.visibility = data.visibility || state.visibility;
    state.digits = data.digits || state.digits;
    state.secret = data.secret || state.secret;
    state.gameStarted = true;
    state.timerStarted = false;

    setupGroupGameUI();
    listenForGuesses();
    listenForTurn();
    if (state.mode === "realtime") startGroupTimer();
  }

  function setupGroupGameUI() {
    document.getElementById("groupGameTitle").textContent = "Group Race";
    document.getElementById("groupModeBadge").textContent = state.mode === "turns" ? "Turn-Based" : "Real-Time";
    document.getElementById("groupRoundBadge").textContent = `Round ${state.round}`;
    document.getElementById("groupRoomBadge").textContent = `Room: ${state.roomCode}`;
    document.getElementById("groupTimerBadge").style.display = state.mode === "realtime" ? "inline-flex" : "none";
    document.getElementById("groupGuessInput").maxLength = state.digits;
    document.getElementById("groupGuessInput").value = "";
    buildGroupHistories();
    updateGroupTurnUI();
    showPage("pageGroupGame");
  }

  function buildGroupHistories() {
    const wrap = document.getElementById("groupHistoryWrap");
    wrap.innerHTML = "";
    Object.entries(state.players).forEach(([pid, p]) => {
      const isMe = pid === state.playerId;
      if (state.visibility === "hard" && !isMe) return;
      const div = document.createElement("div");
      div.innerHTML = `<div class="section-title"><h3>${p.name}${isMe ? " (You)" : ""}</h3><span id="groupCount_${pid}">0</span></div>
        <ul class="history-list" id="groupHistory_${pid}"></ul>`;
      wrap.appendChild(div);
    });
  }

  function listenForGuesses() {
    const roomRef = fbRef(`groups/${state.roomCode}/guesses`);
    const off = roomRef.on("value", snap => {
      const data = snap.val() || {};
      state.guesses = data;
      renderGroupGuesses();
    });
    listeners.push(() => roomRef.off("value", off));
  }

  function listenForTurn() {
    const roomRef = fbRef(`groups/${state.roomCode}`);
    const off = roomRef.child("currentTurn").on("value", snap => {
      state.currentTurn = snap.val();
      updateGroupTurnUI();
    });
    listeners.push(() => roomRef.child("currentTurn").off("value", off));

    const off2 = roomRef.child("phase").on("value", snap => {
      const phase = snap.val();
      if (phase && phase.startsWith("win:")) {
        const wid = phase.split(":")[1];
        handleGroupWin(wid);
      } else if (phase === "draw") {
        handleGroupDraw();
      } else if (phase === "playing" && state.gameOver) {
        clearListeners();
        fbRef(`groups/${state.roomCode}`).once("value", snap => startGroupGame(snap.val()));
      }
    });
    listeners.push(() => roomRef.child("phase").off("value", off2));
  }

  function isMyGroupTurn() {
    if (state.mode === "realtime") return true;
    return state.currentTurn === state.playerId;
  }

  function updateGroupTurnUI() {
    const myTurn = isMyGroupTurn();
    document.getElementById("groupGuessInput").disabled = !myTurn || state.gameOver;
    document.getElementById("groupGuessBtn").disabled = !myTurn || state.gameOver;
    const label = document.getElementById("groupTurnLabel");
    if (state.mode === "turns") {
      const cp = state.players[state.currentTurn];
      label.textContent = myTurn ? "Your turn!" : `Waiting for ${cp ? cp.name : "next player"}…`;
      label.style.borderColor = myTurn ? "var(--cyan)" : "var(--line)";
    } else {
      label.textContent = "Real-Time — guess whenever!";
    }
  }

  function submitGuess(raw) {
    if (!isMyGroupTurn() || state.gameOver) return;
    const guess = raw.trim();
    if (!isValidCode(guess, state.digits)) {
      showMessage("groupMessage", `Guess must be ${state.digits} unique digits.`, "var(--red)");
      return;
    }
    hideMessage("groupMessage");

    const { greens, yellows } = scoreGuess(state.secret, guess);
    const entry = { guess, greens, yellows, ts: Date.now() };
    const myGuesses = (state.guesses[state.playerId] && Object.values(state.guesses[state.playerId])) || [];
    const key = `g${myGuesses.length + 1}`;
    fbRef(`groups/${state.roomCode}/guesses/${state.playerId}/${key}`).set(entry);
    document.getElementById("groupGuessInput").value = "";

    if (greens === state.digits) {
      const newScore = (state.scores[state.playerId] || 0) + 1;
      fbRef(`groups/${state.roomCode}/scores/${state.playerId}`).set(newScore);
      fbRef(`groups/${state.roomCode}/phase`).set(`win:${state.playerId}`);
      return;
    }

    // Advance turn
    if (state.mode === "turns") {
      const pids = Object.keys(state.players).sort();
      const idx = pids.indexOf(state.playerId);
      const next = pids[(idx + 1) % pids.length];
      state.currentTurn = next;
      updateGroupTurnUI();
      fbRef(`groups/${state.roomCode}/currentTurn`).set(next);
    }
  }

  function renderGroupGuesses() {
    Object.entries(state.guesses).forEach(([pid, gdata]) => {
      const arr = Object.values(gdata || {}).sort((a, b) => a.ts - b.ts);
      const isMe = pid === state.playerId;
      if (state.visibility === "hard" && !isMe) return;
      const list = document.getElementById(`groupHistory_${pid}`);
      const countEl = document.getElementById(`groupCount_${pid}`);
      if (!list) return;
      list.innerHTML = "";
      if (countEl) countEl.textContent = arr.length;
      arr.forEach((g, i) => {
        if (isMe) {
          list.appendChild(renderHistoryItem(state.secret, g.guess, `#${i+1} — ${g.guess}`));
        } else {
          list.appendChild(renderHistoryItemPublic(g.guess, g.greens, g.yellows, `#${i+1} — ${g.guess}`));
        }
      });
    });
  }

  function handleGroupWin(winnerId) {
    if (state.gameOver) return;
    state.gameOver = true;
    stopTimer();
    const wName = (state.players[winnerId] || {}).name || winnerId;
    const iWon = winnerId === state.playerId;
    showRoundEnd(iWon ? "You won the round!" : `${wName} wins!`,
      `The code was ${state.secret}.`,
      [
        { label: "Next Round", primary: true, action: () => nextGroupRound() },
        { label: "Quit", primary: false, action: () => groupQuit() }
      ]
    );
  }

  function handleGroupDraw() {
    if (state.gameOver) return;
    state.gameOver = true;
    stopTimer();
    showRoundEnd("Time's Up!", "No one cracked the code in time.",
      [
        { label: "Overtime (+2 min)", primary: true, action: () => startGroupOvertime() },
        { label: "Draw — Quit", primary: false, action: () => groupQuit() }
      ]
    );
  }

  function startGroupOvertime() {
    state.timerSecs = 120;
    state.gameOver = false;
    fbRef(`groups/${state.roomCode}`).child("timerEnd").set(Date.now() + 120000);
    startGroupTimer(120);
    updateGroupTurnUI();
  }

  function startGroupTimer(secs) {
    if (state.timerStarted && !secs) return;
    state.timerStarted = true;
    stopTimer();
    const dur = secs || state.timerSecs;
    const end = Date.now() + dur * 1000;
    fbRef(`groups/${state.roomCode}/timerEnd`).set(end);
    const badge = document.getElementById("groupTimerBadge");
    badge.style.display = "inline-flex";
    timerInterval = setInterval(() => {
      const rem = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      const m = Math.floor(rem / 60);
      const s = rem % 60;
      badge.textContent = `${m}:${String(s).padStart(2, "0")}`;
      if (rem === 0) {
        stopTimer();
        if (!state.gameOver && state.isHost) {
          fbRef(`groups/${state.roomCode}/phase`).set("draw");
        }
      }
    }, 500);
  }

  function nextGroupRound() {
    state.round++;
    clearListeners();
    stopTimer();
    const newSecret = randomCode(state.digits);
    state.secret = newSecret;
    state.gameOver = false;
    state.gameStarted = false;
    state.timerStarted = false;
    state.guesses = {};
    const pids = Object.keys(state.players).sort();
    fbRef(`groups/${state.roomCode}`).update({
      round: state.round, phase: "playing",
      secret: newSecret, currentTurn: pids[0], guesses: {}
    });
    setTimeout(() => startGroupGame({
      players: state.players, scores: state.scores, mode: state.mode,
      digits: state.digits, visibility: state.visibility,
      currentTurn: pids[0], round: state.round
    }), 300);
  }

  return { createRoom, joinRoom, submitGuess };
})();

window.groupQuit = function() { showPage("pageHome"); };

document.getElementById("groupStartBtn").addEventListener("click", e => {
  e.preventDefault();
  const name = document.getElementById("groupPlayerName").value.trim() || "Player";
  const joinType = segValue("groupJoinSeg") || "create";
  withDatabase("Group Race", () => {
    if (joinType === "create") {
      const digits = document.getElementById("groupDigits").value;
      const playerCount = document.getElementById("groupSize").value;
      const mode = segValue("groupModeSeg") || "turns";
      const vis = segValue("groupVisSeg") || "easy";
      GroupGame.createRoom(name, digits, playerCount, mode, vis);
    } else {
      const code = document.getElementById("groupJoinCode").value.trim();
      if (!code) { alert("Enter a room code to join."); return; }
      GroupGame.joinRoom(name, code);
    }
  });
});

document.getElementById("groupGuessBtn").addEventListener("click", e => {
  e.preventDefault();
  GroupGame.submitGuess(document.getElementById("groupGuessInput").value);
});
document.getElementById("groupGuessInput").addEventListener("keydown", e => {
  if (e.key === "Enter") {
    e.preventDefault();
    GroupGame.submitGuess(document.getElementById("groupGuessInput").value);
  }
});

/* ─── Init ──────────────────────────────────────────────── */
showPage("pageHome");
